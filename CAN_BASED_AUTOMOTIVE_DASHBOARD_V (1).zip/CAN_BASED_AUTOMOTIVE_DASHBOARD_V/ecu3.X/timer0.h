/*
 * File:   timer0.h
 * Author: Vijayalaxmi
 *
 * Created on 2 January, 2026, 5:17 PM
 */


#include <xc.h>

#ifndef TIMER0_H
#define TIMER0_H

void init_timer0(void);

#endif