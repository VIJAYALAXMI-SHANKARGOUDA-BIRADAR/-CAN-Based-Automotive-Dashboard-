/*
 * File:   isr.c
 * Author: Vijayalaxmi
 * 
 *
 * Created on 2 January, 2026, 5:19 PM
 */

#include <xc.h>
#include "message_handler.h"
extern int flag2;
int flag1;

void __interrupt() isr(void)
{
    static unsigned int count=0;
    if(TMR0IF)
    {
       
        TMR0IF=0;
        TMR0=TMR0+8;
        
        if(count++==20000)
        {
            count=0;
            flag1=!flag1;
        }
        if(flag2==1)
        {
            
          if(flag1==1)
           {
              RB0=1;
              RB1=1;
              RB6=0;
              RB7=0; 
            }
          else{
              RB0=0;
              RB1=0;
              
          }
        }    
        else if(flag2==2)
            
        {
           
            if(flag1==1)
            {
              RB6=1;
              RB7=1;
              RB0=0;
              RB1=0;
              

            }
            else{
              RB6=0;
              RB7=0; 
              
            }
                
        }
        else if(flag2==3)
        {
            
            LEFT_IND_OFF();
            RIGHT_IND_OFF();
        }
       
        
    }
}