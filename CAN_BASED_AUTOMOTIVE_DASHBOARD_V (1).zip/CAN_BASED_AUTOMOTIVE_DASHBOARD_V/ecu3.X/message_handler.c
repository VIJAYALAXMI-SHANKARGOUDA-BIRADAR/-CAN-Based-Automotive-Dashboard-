/*
 * File:   message_handler.c
 * Author: Vijayalaxmi
 *
 * Created on 2 January, 2026, 5:22 PM
 */


#include <xc.h>
#include <string.h>
#include "message_handler.h"
#include "msg_id.h"
#include "can.h"
#include "clcd.h"


volatile unsigned char led_state = LED_OFF, status = e_ind_off;


//void handle_speed_data(uint8_t *data, uint8_t len)
//{
//    //Implement the speed function
//    clcd_print(data,LINE2(0));
//    
//}
//
//void handle_gear_data(uint8_t *data, uint8_t len) 
//{
//    //Implement the gear function
//    
//    clcd_print(data,LINE2(4));
//
//}
//
//void handle_rpm_data(uint8_t *data, uint8_t len) 
//{
//    //Implement the rpm function
//}
//
//void handle_engine_temp_data(uint8_t *data, uint8_t len) 
//{
//    //Implement the temperature function
//}
//
//void handle_indicator_data(uint8_t *data, uint8_t len) 
//{
//    //Implement the indicator function
//}
//void process_canbus_data() 
//{   
    //process the CAN bus data
//    clcd_print("SP",LINE1(0));
//    clcd_print("EV",LINE1(4));
//    clcd_print("RPM",LINE1(7));
//    clcd_print("ind",LINE1(12));
//    
//   unsigned int msg_id=0;
//   unsigned char data[5];
//   unsigned int len=0;
//   
//  // handle_speed_data()
//   
//   can_receive(&msg_id,data,&len);
//   
////   if(msg_id==SPEED_MSG_ID)
////   {
////       data[len]='\0';
////       handle_speed_data(data,len);
////       
////   }
//   
////   if(msg_id==GEAR_MSG_ID)
////   {
////       data[len]='\0';
////       handle_gear_data(data,len);
////       
////   }
//   
//   
//   
//    
//}
