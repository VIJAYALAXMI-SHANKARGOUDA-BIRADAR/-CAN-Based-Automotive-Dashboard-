/*
 * File:   main.c
 * Author: vijayalaxmi
 * 
 *
 * Created on 2 January, 2026, 5:21 PM
 */


#include <xc.h>
#include <stdint.h>
#include "can.h"
#include "clcd.h"
#include "msg_id.h"
#include "message_handler.h"
#include "timer0.h"

 int flag2;
static int init_leds()
 {
    TRISB = 0x08; // Set RB2 as output, RB3 as input, remaining as output
    PORTB = 0x00;
}

static void init_config(void) 
{
    // Initialize CLCD and CANBUS
    init_clcd();
    init_can();
    init_leds();

    // Enable Interrupts
    PEIE = 1;
    GIE = 1;
    init_timer0();
}

void main(void) {
    // Initialize peripherals
    init_config();
    
     uint16_t msg_id=0;
     uint8_t data[5];
     uint8_t len=0;
     
    /* ECU1 main loop */
    clcd_print("SP",LINE1(0));
    clcd_print("EV",LINE1(4));
    clcd_print("RPM",LINE1(7));
    clcd_print("IND",LINE1(13));
    
  while (1) 
  {
       can_receive(&msg_id,data,&len);
            // Read CAN Bus data and handle it
       if(msg_id==SPEED_MSG_ID)
       {
           data[len]='\0';
           clcd_print(data,LINE2(0));

       }

       else if(msg_id==GEAR_MSG_ID)
       {
           data[len]='\0';
           //handle_gear_data(data,len)
             clcd_print(data,LINE2(4));


       }


       else if(msg_id==RPM_MSG_ID)
       {
            data[len]='\0';
            clcd_print(data,LINE2(7));
       }


      else if(msg_id==INDICATOR_MSG_ID)
      {

       data[len]='\0';

        if(data[0]==2)
        {
            flag2=2;
        clcd_print("->",LINE2(13));
        }
        else if(data[0]==1)
        {
            flag2=1;
        clcd_print("<-",LINE2(13));
        }
        else if(data[0]==3)
        {
            flag2=3;
            clcd_print("   ",LINE2(12));
        }
   }
 
    
    }

  
}
