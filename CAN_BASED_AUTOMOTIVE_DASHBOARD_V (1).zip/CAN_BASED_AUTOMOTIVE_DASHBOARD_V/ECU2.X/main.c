#include "ecu2_sensor.h"
#include "adc.h"
#include "ssd_display.h"

#include "can.h"
#include "msg_id.h"

//#include "uart.h"



void init_config()
{
    //LED
    TRISB0=0;
    TRISB1=0;
    TRISB6=0;
    TRISB7=0;
    
    
    PORTB =0X00;
    
    
    
    //timer0
    GIE=1;
    PEIE=1;
    
    T08BIT=1;
    T0CS=0;
    
    TMR0ON=1;
    PSA=1;
    TMR0=6;
    TMR0IE=1;
    TMR0IF=0;
    
    
    init_ssd();
    init_adc();
    
    init_digital_keypad();
    init_can();
    
    
}
int main()
{
    //call the functions
    
    init_config();
    char flag[2];
    while(1)
    {
        
        get_rpm();
        process_indicator();
    
        
    }
    
    
}
