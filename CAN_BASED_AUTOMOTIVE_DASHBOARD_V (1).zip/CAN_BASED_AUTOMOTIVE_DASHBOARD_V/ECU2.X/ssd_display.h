#ifndef SSD_DISPLAY_H  
#define SSD_DISPLAY_H  

#include <xc.h> 
#define ZERO 0XE7
#define ONE 0X21
#define TWO 0XCB
#define THREE 0X6B
#define FOUR 0X2D
#define FIVE 0X6E
#define SIX 0XEE
#define SEVEN 0X23
#define EIGHT 0XEF
#define NINE 0X6F

#define SW1 0X0E;

void init_dkp();
char read_dkp(unsigned int input);

void init_ssd();
void display(char arr[]);





#endif