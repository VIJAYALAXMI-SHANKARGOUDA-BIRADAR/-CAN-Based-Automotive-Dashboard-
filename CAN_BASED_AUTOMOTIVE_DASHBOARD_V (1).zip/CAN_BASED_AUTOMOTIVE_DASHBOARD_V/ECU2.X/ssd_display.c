#include <xc.h>
#include "ssd_display.h"

void init_ssd()
{
    TRISD=0;
    TRISA=TRISA & 0XF0;
    
}

void display(char arr[])
{
    //unsigned int d=0;
    for(int i=0;i<4;i++)
    {
        PORTD=arr[i];
        PORTA=1<<i;
        for(unsigned int d=1000;d--;);
    }
}