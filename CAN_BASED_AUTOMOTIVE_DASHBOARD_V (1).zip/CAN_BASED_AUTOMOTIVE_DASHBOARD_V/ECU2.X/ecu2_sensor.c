#include "ecu2_sensor.h"
#include "adc.h"
#include "digital_keypad.h"
#include "ssd_display.h"
#include "can.h"
#include "msg_id.h"

    //unsigned char digit[]={0xE7,0X21,0XCB,0X6B,0X2D,0X6E,0XEE,0X23,0XEF,0X6F,0X40,0X40};
    unsigned char ssd[4];

//uint16_t RPM;
uint16_t get_rpm()
{
  
    uint16_t RPM;
    
    unsigned int rpm_msg_id=0;
    uint8_t len=0;
    unsigned char data[4];
   
  
    
    RPM = (read_adc(CHANNEL4)/10.23)*60;
     
    
       ssd[3]=(RPM %10)+'0';
       ssd[2]=((RPM/10)%10)+'0';
       ssd[1]=((RPM/100)%10) + '0';
       ssd[0]=(RPM/1000)+'0';
           
       can_transmit(RPM_MSG_ID,ssd,4);
       __delay_ms(80);
       
//       can_receive(&rpm_msg_id,data,&len);
//       
//       if(RPM_MSG_ID==rpm_msg_id)
//       {
//           display(ssd);
//     
//       }
                
       
}

////unsigned int delay1=0;
////unsigned int delay2=0;


IndicatorStatus process_indicator()
{
    char flag[2];
    //Implement the indicator functioN
      unsigned char key;
    
        key=read_digital_keypad(STATE_CHANGE);
       

        if(key==SWITCH1)
        {
            PORTB=0X00;
            flag[0]=1;
            flag[1]='\0';
            
        }
        else if(key==SWITCH2)
        {
            PORTB=0X0;
            
            flag[0]=2;
            flag[1]='\0';
        }
        else if(key==SWITCH3)
        {
            PORTB=0;
            flag[0]=3;
            flag[1]='\0';
        }
        
       can_transmit(INDICATOR_MSG_ID,flag,2);
       __delay_ms(80);
      
     
    
////        if(flag==1)
////        {
////            
////          if(delay1++==100)
////           {
////            delay1=0;
////
////            //PORTB=PORTB^0XC0;
////            RB0=!RB0;
////            RB1=!RB1;
////            
////           
////          }
////        }    
////        else if(flag==2)
////            
////        {
////          
////            if(delay1++==100)
////            {
////                delay1=0;
////               // PORTB=PORTB^0X03;
////                RB6=!RB6;
////                RB7=!RB7;
////                
////            }
////                
////        }
////        else if(flag==3)
////        {
////            PORTB=0X00;         
////        }
      
}