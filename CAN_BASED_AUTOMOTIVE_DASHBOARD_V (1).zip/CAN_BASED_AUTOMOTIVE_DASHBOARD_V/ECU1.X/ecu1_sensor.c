#include "ecu1_sensor.h"
#include "adc.h"
#include "clcd.h"


#include "can.h"
#include "msg_id.h"
//#include "uart.h"

extern char event[10][3] = {"ON","GN","G1","G2","G3","G4","G5","GR","C-"};
unsigned char index=0;
void get_speed()
{
    // Implement the speed function
    
    uint16_t speed;
    unsigned char arr[3];
    
   // clcd_print("SPEEd",LINE1(0));
    speed=read_adc(CHANNEL4)/10.33;//read speed from potentiometer
    arr[0]=(speed/10)+'0';
    arr[1]=(speed%10)+'0';
    arr[2]='\0';
    
    
//    unsigned int s_msg_id=0;
//    int len=0;
//    unsigned char data[3];
    
   // clcd_print("Tx data",LINE1(0));
    
    can_transmit(SPEED_MSG_ID,arr,2);
    
    __delay_ms(80);
    
//    can_receive(&s_msg_id,data,&len);
//    
//    if(s_msg_id==SPEED_MSG_ID)
//    {
//        data[2]='\0';
//    
//       clcd_print(data,LINE2(0));
//    //clcd_putch(arr[1],LINE2(2));
//   
//    }
      
}

void get_gear_pos()
{
    unsigned int g_msg_id=0;
    unsigned int len=0;
    unsigned char data[3];
    //unsigned char data[3];
    
    
    // Implement the gear function
    unsigned char key=read_switches(STATE_CHANGE);
   // clcd_print("GEAR",LINE1(8));
    if(key==MK_SW1)
    {
        if(index==7)
        {
            index=7;
        }
        else if(index==8)
        {
            index=1;
        }
        else
            index++;
    }
    else if(key==MK_SW2)
    {
        if(index==0)
        {
            index=0;
        }
        else if(index==8)
        {
            index=1;
        }
        else
            index--;
    }
    else if(key==MK_SW3)
    {
        index=8;
    }
    
    
        can_transmit(GEAR_MSG_ID,event[index],2);
            __delay_ms(80);
            
//        can_receive(&g_msg_id,data,&len);
//      
//            if(g_msg_id==GEAR_MSG_ID)
//            {
//                data[2]='\0';
//
//                clcd_print(data,LINE2(8));
//
//            }
            
}
    
