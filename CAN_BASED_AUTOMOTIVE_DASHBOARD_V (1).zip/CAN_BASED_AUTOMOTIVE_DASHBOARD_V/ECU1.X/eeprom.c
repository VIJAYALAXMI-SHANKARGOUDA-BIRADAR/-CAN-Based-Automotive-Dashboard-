/*
 * File:   eeprom.c
 * Author: vijay
 *
 * Created on 8 January, 2026, 1:33 PM
 */


#include <xc.h>


