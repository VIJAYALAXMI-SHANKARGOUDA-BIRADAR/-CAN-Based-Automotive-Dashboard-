/*
 * File:   main.c
 * Author: vijay
 *
 * Created on 18 December, 2025, 12:00 AM
 */


#include "adc.h"
#include "can.h"
#include "ecu1_sensor.h"
#include "msg_id.h"
//#include "uart.h"

#include "clcd.h"


    void init_config(void)
    {
        init_clcd();
        init_adc();
        init_matrix_keypad();
        init_can();
    }
    
    //char event[9][3] = {"ON","GN","G1","G2","G3","G4","G5","GR","C-"};

int main()
{
    init_config();
   
    
   
    
  
    //Call the functions
    
    while(1)
    {
        get_speed();
        get_gear_pos();

        
        
     
    }
    
}